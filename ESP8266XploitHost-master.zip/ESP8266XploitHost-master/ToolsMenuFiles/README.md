ESP8266XploitHost - Tools menu files
====================================

Required files for the tools menu. FTP these files to the ESP8266 if you ever delete any of them.

